$(document).ready(function(){
  $('#birth-date').mask('00/00/0000');
  $('#phone-us').mask('(000) 000-0000');
});
